//
//  BookCoverViewController.swift
//  BookAuthors
//
//  Created by Chelsey on 11/22/17.
//  Copyright © 2017 Chelsey Fay. All rights reserved.
//

import UIKit

class BookCoverViewController: UIViewController {
    
    
    @IBOutlet var bookCoverView: UIImageView!
    @IBOutlet var publishYear: UILabel!
    
    var book: [String: String]!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // COnfigure the Image view
        // Ask the book for the value stored at its element with a key of "Cover"
        if let fileName = book["Cover"] {
            
            // Instantiate a UIImage Object by invoking the init(name) initializer
            // passing it the file name of our image.
            bookCoverView.image = UIImage(named: fileName)
            
            // The contentMode property, is of type UIViewContentMode, which is an enumeration.
            // The enumeration value .scaleAspectFit tells the image view to
            // stretch the image as much as posisble while respecting its aspect ratio
            bookCoverView.contentMode = .scaleAspectFit
            
        }
        
        if let bookYear = book["Year"] {
            
            publishYear.text = bookYear
            
        }
        
        if let bookTitle = book["Title"] {
            title = bookTitle
        }
        
    }

   

}
