//
//  BooksViewController.swift
//  BookAuthors
//
//  Created by Chelsey on 11/20/17.
//  Copyright © 2017 Chelsey Fay. All rights reserved.
//

import UIKit

class BooksViewController: UITableViewController {
    
    let CellIdentifier = "Cell Identifier"
    let SegueBookCoverViewController = "BookCoverViewController"

    
    // Notice the ! for force unwrapping. It needs t have a valuse for our application to work correctly. This property will get set in AuthorsViewController class.
    var author: [String: AnyObject]!
    
    // Define a computed property named books. A computed property does not store a value. It defines a getter (and potentially a setter) for getting/setting the value of another property.
   /*
    var books: [AnyObject] {
        get {
            if let books = author["Books"]  as? [AnyObject]{
                return books;
            } else {
                return [AnyObject]()
            
            }
        
    }
     // DO the above code without the get{} block
        */
    var books: [AnyObject] {
        if let books = author["Books"]  as? [AnyObject]{
                
                return books;
                
            } else {
                return [AnyObject]()
                
            }
    }
        

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        tableView.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: CellIdentifier)
        
        // Set title
        title = "Books"
        
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier, for: indexPath)
        
        if let book = books[indexPath.row] as? [String: String], let title = book["Title"]{

        // Configure the cell...
            cell.textLabel?.text = title
            
        }
            return cell
        
        }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: SegueBookCoverViewController, sender: self)
        
        // Clean up
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        
        if segue.identifier == SegueBookCoverViewController {
            
            // Ask the table view for the index path of the currently selected row and
            // ask books for the book that corresponds with the touched row.
            if let indexPath = tableView.indexPathForSelectedRow, let book = books[indexPath.row] as? [String: String] {
                // Set the book property of the destination view controller (BookViewController)
                let destinationViewController = segue.destination as! BookCoverViewController
                
                destinationViewController.book = book
                
                
            }
            
        }
        
    }


}
