//
//  AuthorsViewController.swift
//  BookAuthors
//
//  Created by Chelsey on 11/15/17.
//  Copyright © 2017 Chelsey Fay. All rights reserved.
//

import UIKit

class AuthorsViewController: UITableViewController {

    var authors = [AnyObject]()
    
    // Declare a constant for the cell reuse identifier we will be using...
    let CellIdentifier = "Cell Identifier"

    // Set up a constant to reflect the Identifier we gave ur Show Segue
    let SegueBooksViewController = "BooksViewController"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        //Set up a file path to grab the fiel requested
        let filePath = Bundle.main.path(forResource: "Books", ofType: "plist")
        
        if let path = filePath {
            
            //Initialize our authors array with the contents of the file provided at our path
            // (Books.plist)
            authors = NSArray(contentsOfFile: path)! as [AnyObject]
        }
        // UITableView's register(forClass:forCellReuseIdentifier:) method registers a class for use in creating new table cells.
        //
        // The classCoder() method of UITableViewCell class is overridden by subclasses to substitute a class other than its own during coding.
        tableView.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: CellIdentifier)
        
        // Set title on the navigation bar
        title = "Authors"
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows
        return authors.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue reusable cell give us a UITableViewCell instance
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier, for: indexPath)

        if let author = authors[indexPath.row] as? [String: AnyObject],
            let name = author["Author"] as? String {
            
            // Configure the cell...
            cell.textLabel?.text = name
            
        }
        return cell
    }
    
    // The following method is defined in the the UITableViewDelegate protocol and is needed to put our show segue from the Authors View Controller to the books view controller
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
            // Perform our show segue which initiates the segue with the specified identifier from the current view controller's story
        performSegue(withIdentifier: SegueBooksViewController, sender: self)
        
        
            // The following method deselects a given row identified by indexPath, with an option to animate the deselection. Here, we reset the selection AFTER performing the segue
        tableView.deselectRow(at: indexPath, animated: true)
        
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        // First, check if the segue's identifier is what we expect it to be
        if segue.identifier == SegueBooksViewController {
            
            // Ask the tableview for the index path of the current row selection
            // (row that was touched) using optional binding (if-let), and then
            // if a row has been selected, obtain from authors array the author
            // that corresponds with the row that was touched.
            if let indexPath = tableView.indexPathForSelectedRow, let author = authors[indexPath.row] as? [String: AnyObject] {
                
                //Get a reference to the destination view controller for this segue
                // (BooksViewController) and set its author property to the currently
                // selected author in the table view as obtained in the second part
                // (nexted if) of the optional binding chain above...
                let destinationViewController = segue.destination as! BooksViewController
                
                // Set BooksViewController's author property (declared in BooksViewController.swift)
                destinationViewController.author = author
                

                
            }
            
        }
        
    }
    
 }

