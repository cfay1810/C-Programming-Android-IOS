﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim intMaxValue As Integer 'To hold the maximum value
        Dim intSum As Integer = 0 'Accumulator
        Dim intCount As Integer 'Counter Variable

        'Get the maximum value from the user
        intMaxValue = CInt(InputBox("Enter a positive integer value."))

        'Validate the input.
        Do While intMaxValue < 0
            intMaxValue = CInt(InputBox("Enter a POSITIVE integer value."))
        Loop

        'Caclulate the sum of numbers 1 through the max value
        For intCount = 1 To intMaxValue
            intSum = intSum + intCount
        Next

        ' Display the result.
        MessageBox.Show("The sum of the numbers 1 through " & CStr(intMaxValue) &
                        " is " & CStr(intSum))
    End Sub
End Class
