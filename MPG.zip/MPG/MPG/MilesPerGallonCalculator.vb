﻿Public Class MilesPerGallonCalculator

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblGallonsOfGas.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Define Variables
        Dim dblGallons As Double 'txtGallonsOfGas
        Dim dblMiles As Double  'txtNumberOfMiles
        Dim dblMPG As Double    'txtMilesPerGallon

        ' Need the input
        dblGallons = CDbl(txtGallonsOfGas.Text)
        dblMiles = CDbl(txtNumberOfMiles.Text)

        'Calculate the miles per gallon
        dblMPG = dblMiles / dblGallons

        'Display the results
        txtMilesPerGallon.Text = CStr(dblMPG)

    End Sub

    Private Sub MilesPerGallonCalculator_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtGallonsOfGas.Text = String.Empty
        txtNumberOfMiles.Text = String.Empty
        txtMilesPerGallon.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class
