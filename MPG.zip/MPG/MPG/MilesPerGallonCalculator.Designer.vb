﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MilesPerGallonCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblGallonsOfGas = New System.Windows.Forms.Label()
        Me.lblNumOfMiles = New System.Windows.Forms.Label()
        Me.lblMilesPerGallon = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtGallonsOfGas = New System.Windows.Forms.TextBox()
        Me.txtNumberOfMiles = New System.Windows.Forms.TextBox()
        Me.txtMilesPerGallon = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblGallonsOfGas
        '
        Me.lblGallonsOfGas.AutoSize = True
        Me.lblGallonsOfGas.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGallonsOfGas.Location = New System.Drawing.Point(72, 34)
        Me.lblGallonsOfGas.Name = "lblGallonsOfGas"
        Me.lblGallonsOfGas.Size = New System.Drawing.Size(142, 40)
        Me.lblGallonsOfGas.TabIndex = 0
        Me.lblGallonsOfGas.Text = "Gallons of gas the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "car can hold:"
        '
        'lblNumOfMiles
        '
        Me.lblNumOfMiles.AutoSize = True
        Me.lblNumOfMiles.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumOfMiles.Location = New System.Drawing.Point(73, 91)
        Me.lblNumOfMiles.Name = "lblNumOfMiles"
        Me.lblNumOfMiles.Size = New System.Drawing.Size(143, 54)
        Me.lblNumOfMiles.TabIndex = 1
        Me.lblNumOfMiles.Text = "Number of Miles " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "it can be driven on a " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "full tank:"
        '
        'lblMilesPerGallon
        '
        Me.lblMilesPerGallon.AutoSize = True
        Me.lblMilesPerGallon.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMilesPerGallon.Location = New System.Drawing.Point(73, 166)
        Me.lblMilesPerGallon.Name = "lblMilesPerGallon"
        Me.lblMilesPerGallon.Size = New System.Drawing.Size(122, 20)
        Me.lblMilesPerGallon.TabIndex = 2
        Me.lblMilesPerGallon.Text = "Miles per gallon:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(42, 239)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(95, 48)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Caculate " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "MPG"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(160, 239)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(84, 48)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(271, 239)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(81, 48)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtGallonsOfGas
        '
        Me.txtGallonsOfGas.Location = New System.Drawing.Point(244, 39)
        Me.txtGallonsOfGas.Name = "txtGallonsOfGas"
        Me.txtGallonsOfGas.Size = New System.Drawing.Size(118, 20)
        Me.txtGallonsOfGas.TabIndex = 6
        '
        'txtNumberOfMiles
        '
        Me.txtNumberOfMiles.Location = New System.Drawing.Point(244, 102)
        Me.txtNumberOfMiles.Name = "txtNumberOfMiles"
        Me.txtNumberOfMiles.Size = New System.Drawing.Size(113, 20)
        Me.txtNumberOfMiles.TabIndex = 7
        '
        'txtMilesPerGallon
        '
        Me.txtMilesPerGallon.BackColor = System.Drawing.SystemColors.Control
        Me.txtMilesPerGallon.Location = New System.Drawing.Point(244, 166)
        Me.txtMilesPerGallon.Name = "txtMilesPerGallon"
        Me.txtMilesPerGallon.Size = New System.Drawing.Size(108, 20)
        Me.txtMilesPerGallon.TabIndex = 8
        '
        'MilesPerGallonCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(386, 319)
        Me.Controls.Add(Me.txtMilesPerGallon)
        Me.Controls.Add(Me.txtNumberOfMiles)
        Me.Controls.Add(Me.txtGallonsOfGas)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblMilesPerGallon)
        Me.Controls.Add(Me.lblNumOfMiles)
        Me.Controls.Add(Me.lblGallonsOfGas)
        Me.Name = "MilesPerGallonCalculator"
        Me.Text = "Miles Per Gallon Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGallonsOfGas As System.Windows.Forms.Label
    Friend WithEvents lblNumOfMiles As System.Windows.Forms.Label
    Friend WithEvents lblMilesPerGallon As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtGallonsOfGas As System.Windows.Forms.TextBox
    Friend WithEvents txtNumberOfMiles As System.Windows.Forms.TextBox
    Friend WithEvents txtMilesPerGallon As System.Windows.Forms.TextBox

End Class
