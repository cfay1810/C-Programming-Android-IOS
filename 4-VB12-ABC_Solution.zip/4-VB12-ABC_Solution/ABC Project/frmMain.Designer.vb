<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNumber = New System.Windows.Forms.Label
        Me.txtNumber = New System.Windows.Forms.TextBox
        Me.lblName = New System.Windows.Forms.Label
        Me.txtName = New System.Windows.Forms.TextBox
        Me.lblSalary = New System.Windows.Forms.Label
        Me.lblHours = New System.Windows.Forms.Label
        Me.lblRate = New System.Windows.Forms.Label
        Me.lblGross = New System.Windows.Forms.Label
        Me.lblGrossOutput = New System.Windows.Forms.Label
        Me.lstHours = New System.Windows.Forms.ListBox
        Me.lstRate = New System.Windows.Forms.ListBox
        Me.btnCalc = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.lstSalary = New System.Windows.Forms.ListBox
        Me.rdoSalaried = New System.Windows.Forms.RadioButton
        Me.rdoHourly = New System.Windows.Forms.RadioButton
        Me.gbxEmployee = New System.Windows.Forms.GroupBox
        Me.gbxEmployee.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblNumber
        '
        Me.lblNumber.AutoSize = True
        Me.lblNumber.Location = New System.Drawing.Point(37, 26)
        Me.lblNumber.Name = "lblNumber"
        Me.lblNumber.Size = New System.Drawing.Size(72, 19)
        Me.lblNumber.TabIndex = 0
        Me.lblNumber.Text = "Num&ber:"
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(37, 48)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(53, 27)
        Me.txtNumber.TabIndex = 1
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(118, 26)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(56, 19)
        Me.lblName.TabIndex = 2
        Me.lblName.Text = "&Name:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(118, 48)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(292, 27)
        Me.txtName.TabIndex = 3
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Location = New System.Drawing.Point(207, 65)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(111, 19)
        Me.lblSalary.TabIndex = 6
        Me.lblSalary.Text = "&Annual salary:"
        Me.lblSalary.Visible = False
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.Location = New System.Drawing.Point(17, 65)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(57, 19)
        Me.lblHours.TabIndex = 1
        Me.lblHours.Text = "&Hours:"
        '
        'lblRate
        '
        Me.lblRate.AutoSize = True
        Me.lblRate.Location = New System.Drawing.Point(94, 65)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(46, 19)
        Me.lblRate.TabIndex = 3
        Me.lblRate.Text = "&Rate:"
        '
        'lblGross
        '
        Me.lblGross.AutoSize = True
        Me.lblGross.Location = New System.Drawing.Point(440, 26)
        Me.lblGross.Name = "lblGross"
        Me.lblGross.Size = New System.Drawing.Size(85, 19)
        Me.lblGross.TabIndex = 7
        Me.lblGross.Text = "Gross pay:"
        '
        'lblGrossOutput
        '
        Me.lblGrossOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblGrossOutput.Location = New System.Drawing.Point(442, 48)
        Me.lblGrossOutput.Name = "lblGrossOutput"
        Me.lblGrossOutput.Size = New System.Drawing.Size(118, 27)
        Me.lblGrossOutput.TabIndex = 8
        Me.lblGrossOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lstHours
        '
        Me.lstHours.FormattingEnabled = True
        Me.lstHours.ItemHeight = 19
        Me.lstHours.Location = New System.Drawing.Point(17, 87)
        Me.lstHours.Name = "lstHours"
        Me.lstHours.Size = New System.Drawing.Size(69, 99)
        Me.lstHours.TabIndex = 2
        '
        'lstRate
        '
        Me.lstRate.FormattingEnabled = True
        Me.lstRate.ItemHeight = 19
        Me.lstRate.Location = New System.Drawing.Point(96, 87)
        Me.lstRate.Name = "lstRate"
        Me.lstRate.Size = New System.Drawing.Size(74, 99)
        Me.lstRate.TabIndex = 4
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(442, 104)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(115, 30)
        Me.btnCalc.TabIndex = 5
        Me.btnCalc.Text = "&Calculate"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(442, 142)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(115, 30)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "E&xit"
        '
        'lstSalary
        '
        Me.lstSalary.FormattingEnabled = True
        Me.lstSalary.ItemHeight = 19
        Me.lstSalary.Location = New System.Drawing.Point(207, 87)
        Me.lstSalary.Name = "lstSalary"
        Me.lstSalary.Size = New System.Drawing.Size(104, 99)
        Me.lstSalary.TabIndex = 7
        Me.lstSalary.Visible = False
        '
        'rdoSalaried
        '
        Me.rdoSalaried.Location = New System.Drawing.Point(207, 27)
        Me.rdoSalaried.Name = "rdoSalaried"
        Me.rdoSalaried.Size = New System.Drawing.Size(160, 23)
        Me.rdoSalaried.TabIndex = 5
        Me.rdoSalaried.Text = "&Salaried employee"
        '
        'rdoHourly
        '
        Me.rdoHourly.Checked = True
        Me.rdoHourly.Location = New System.Drawing.Point(17, 27)
        Me.rdoHourly.Name = "rdoHourly"
        Me.rdoHourly.Size = New System.Drawing.Size(175, 23)
        Me.rdoHourly.TabIndex = 0
        Me.rdoHourly.TabStop = True
        Me.rdoHourly.Text = "Hourl&y employee"
        '
        'gbxEmployee
        '
        Me.gbxEmployee.Controls.Add(Me.rdoSalaried)
        Me.gbxEmployee.Controls.Add(Me.lblSalary)
        Me.gbxEmployee.Controls.Add(Me.rdoHourly)
        Me.gbxEmployee.Controls.Add(Me.lstSalary)
        Me.gbxEmployee.Controls.Add(Me.lblHours)
        Me.gbxEmployee.Controls.Add(Me.lblRate)
        Me.gbxEmployee.Controls.Add(Me.lstHours)
        Me.gbxEmployee.Controls.Add(Me.lstRate)
        Me.gbxEmployee.Location = New System.Drawing.Point(37, 104)
        Me.gbxEmployee.Name = "gbxEmployee"
        Me.gbxEmployee.Size = New System.Drawing.Size(373, 209)
        Me.gbxEmployee.TabIndex = 4
        Me.gbxEmployee.TabStop = False
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnCalc
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(636, 366)
        Me.Controls.Add(Me.gbxEmployee)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblGrossOutput)
        Me.Controls.Add(Me.lblGross)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtNumber)
        Me.Controls.Add(Me.lblNumber)
        Me.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ABC Company"
        Me.gbxEmployee.ResumeLayout(False)
        Me.gbxEmployee.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblNumber As System.Windows.Forms.Label
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblSalary As System.Windows.Forms.Label
    Friend WithEvents lblHours As System.Windows.Forms.Label
    Friend WithEvents lblRate As System.Windows.Forms.Label
    Friend WithEvents lblGross As System.Windows.Forms.Label
    Friend WithEvents lblGrossOutput As System.Windows.Forms.Label
    Friend WithEvents lstHours As System.Windows.Forms.ListBox
    Friend WithEvents lstRate As System.Windows.Forms.ListBox
    Friend WithEvents btnCalc As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lstSalary As System.Windows.Forms.ListBox
    Friend WithEvents rdoSalaried As System.Windows.Forms.RadioButton
    Friend WithEvents rdoHourly As System.Windows.Forms.RadioButton
    Friend WithEvents gbxEmployee As System.Windows.Forms.GroupBox

End Class
