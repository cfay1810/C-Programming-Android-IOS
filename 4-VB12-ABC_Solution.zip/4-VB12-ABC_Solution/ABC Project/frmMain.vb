' Project name:         ABC Project
' Project purpose:      The project displays the gross pay
'                       for salaried and hourly employees.
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On

Public Class frmMain

    Private Sub Clearlabel(ByVal sender As Object, ByVal e As System.EventArgs) _
        Handles lstHours.SelectedIndexChanged, _
        lstRate.SelectedIndexChanged, lstSalary.SelectedIndexChanged, _
        rdoHourly.Click, rdoSalaried.Click

        lblGrossOutput.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtNumber_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNumber.Enter
        txtNumber.SelectAll()
    End Sub

    Private Sub txtName_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtName.Enter
        txtName.SelectAll()
    End Sub

    Private Sub rdoHourly_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoHourly.Click
        ' displays the labels and list boxes used 
        ' to enter the number of hours worked and
        ' the rate of pay; hides the label and
        ' list box used to enter the salary

        lblHours.Visible = True
        lstHours.Visible = True
        lblRate.Visible = True
        lstRate.Visible = True
        lblSalary.Visible = False
        lstSalary.Visible = False
    End Sub


    Private Sub rdoSalaried_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoSalaried.Click
        ' displays the label and list boxes used to 
        ' enter the salary; hides the labels and  
        ' list box used to enter the number of 
        ' hours worked and the rate of pay; 

        lblSalary.Visible = True
        lstSalary.Visible = True
        lblHours.Visible = False
        lstHours.Visible = False
        lblRate.Visible = False
        lstRate.Visible = False
    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' fills the list boxes with values, then selects
        ' a default item in each list box

        For decSalary As Decimal = 15000D To 35000D Step 1000D
            lstSalary.Items.Add(decSalary.ToString)
        Next decSalary

        For decHour As Decimal = 0.5D To 40D Step 0.5D
            lstHours.Items.Add(decHour.ToString("N1"))
        Next decHour

        For decRate As Decimal = 7D To 14D Step 0.5D
            lstRate.Items.Add(decRate.ToString("N2"))
        Next decRate

        lstSalary.SelectedItem = "20000"
        lstHours.SelectedItem = "40.0"
        lstRate.SelectedItem = "10.00"
    End Sub

    Private Sub btnCalc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalc.Click
        ' calculates and displays the gross pay


        Dim decAnnualSalary As Decimal
        Dim decHoursWorked As Decimal
        Dim decHourlyRate As Decimal
        Dim decGrossPay As Decimal

        ' Create an Employee object and assign the 
        Dim objEmployee As New clsEmployee(txtNumber.Text, txtName.Text)

        ' determine which radio button is checked
        If rdoHourly.Checked = True Then
            'Calculate Gross Pay
            decHoursWorked = CDec(lstHours.SelectedItem)
            decHourlyRate = CDec(lstRate.SelectedItem)
            decGrossPay = objEmployee.CalculateGross(decHoursWorked, decHourlyRate)
        Else
            'Calculate Gross Pay
            decAnnualSalary = Convert.ToDecimal(lstSalary.SelectedItem)
            decGrossPay = objEmployee.CalculateGross(decAnnualSalary)
        End If

        ' display the gross pay
        lblGrossOutput.Text = decGrossPay.ToString("C2")

        txtNumber.Focus()
    End Sub
End Class
