﻿' Project name:         Employee Class
' Project purpose:      Manage Employee data and methods.
' Created/revised by:   <your name> on <current date>

Option Strict On
Option Explicit On

Public Class clsEmployee

    'Create Module level Variables
    Private mstrEmpNumber As String
    Private mstrEmpName As String

    'Create Public Properties
    Public Property Employee_Number As String
        Get
            Return mstrEmpNumber
        End Get
        Set(value As String)
            mstrEmpNumber = value
        End Set
    End Property

    Public Property Employee_Name As String
        Get
            Return mstrEmpName
        End Get
        Set(value As String)
            mstrEmpName = value
        End Set
    End Property

    'Create Constructors
    'Default Constructor
    Public Sub New()
        mstrEmpName = String.Empty
        mstrEmpNumber = String.Empty
    End Sub
    'Overload Constructor
    Public Sub New(ByVal strNum As String, ByVal strName As String)
        mstrEmpName = strNum
        mstrEmpNumber = strName
    End Sub

    'Create Methods
    Public Overloads Function CalculateGross(ByVal decSalary As Decimal) As Decimal
        Return decSalary / 24D
    End Function

    Public Overloads Function CalculateGross(ByVal decHours As Decimal, ByVal decRate As Decimal) As Decimal
        Return decHours * decRate
    End Function

End Class
