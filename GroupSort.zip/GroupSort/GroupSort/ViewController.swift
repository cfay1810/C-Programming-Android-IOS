//
//  ViewController.swift
//  GroupSort
//
//  Created by Chelsey on 10/30/17.
//  Copyright © 2017 Fay, Chelsey. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rosterLabel: UILabel!
    var numGroups = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // Set number of groups is called when user taps setNumberOfGroups button
    @IBAction func setNumberOfGroups(_ sender: UIButton) {
        // Create an alert popup to ask how many groups user wants
        //roster sorted into
        //
        //alerts require 4-steps:
        //
        // Step 1: Create an instance of the UIAlertController class
        let alert = UIAlertController(title: "Number of Groups", message: "How many groups would you like?", preferredStyle: .alert)
        
        // Step 2: Create action(s) related to buttons on alert
        let saveAction = UIAlertAction(title: "Save", style: .default){
            [unowned self] action in
            
            guard let textField = alert.textFields?.first, let numGroupsToSave = textField.text else {
                return
            }
            
            // Check if the number we got from the alert text field is a valid integer. If it is not set the numGroups property back to 1.
            if let groupQuantity = Int(numGroupsToSave) {
                self.numGroups = groupQuantity
            } else {
                self.numGroups = 1
            }
            
            print("Number of groups = \(self.numGroups)")

        }
        
        // Set up a Cancel Action button for oue alert
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        
        //Add a text field to our alert popup
        alert.addTextField()
        
        //Step 3: Add action(s) to the alert object created in Step 1
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        //Step 4: Present the alert to the user
        present(alert, animated: true)
        
        
    }
    
    //
    // groupSort is called when the Sort button is tapped.
    @IBAction func groupSort(_ sender: UIButton) {
        // Get location to roster.txt

         let fileName = Bundle.main.url(forResource: "roster", withExtension: "txt")!
        // Use a do-catch bloack which is similar to try-catch blocks in other languages.
        
        // The do block runs code (and can include try statements), the catch block is used for error processing if the do code fails

    
        // Note: Multiple catch blocks can be present with patterns for specific error conditions.
         
       //If a catch block has no pattern (or _) it will handle any error that occurs.
        
        do {
            
            // 1. Read contents of file - roster.txt - into a string
            // open and receive the contents of roster.txt to randomize groups
            //The string classes init(contenetsOf: coding) init method produces
            // a string created by rading
            let fileContent = try String(contentsOf: fileName, encoding: String.Encoding.utf8)
            
             
           

             // 2. Retrieve array of students from file string

            let students = fileContent.components(separatedBy: "\n")

             // 3. Randomize the array of students
            let randomizedStudents = randomize(students)

            // The components (seperatedBy:) method returns an array of
            // substrings from the given string (fileContent) that have been divided based on the "\n|" character
             // 4. Divide randomized students into groups
            let groups = divideIntoGroups(randomizedStudents, numGroups)
             // 5. Create text for roster label for our groups
            var groupNumber = 1
            var output = ""
            
            for group in groups {
                // concatenate new output onto our output string
                output += createOutputForGroup(group, withGroupNumber: groupNumber)
                groupNumber += 1
            }
            
            rosterLabel.text = output
            
        } catch _ {
            /* TODO - do something here for errors in the future */
        }
        
    }
        // file private means that his function is provate to code in this file.
        //
        // private means that the items would only be available to code within its lexical scope meaning code within the curly braces, neans already
        // Note the use of the _ in the parameter lsit, which means that, whthis method i
        fileprivate func randomize(
            _ arrayofStrings: [String]) -> [String] {
            
            //If the array only has one or no elements, then don't doing any randomizing...
            if arrayofStrings.count < 2 {
                return arrayofStrings
            }
            
            var list = arrayofStrings
            
            //Step trough array one element at a time
            for index in 0..<(list.count - 1) {
            
            // Get a random index number from within the array
            let randomIndex = Int(arc4random_uniform(UInt32(list.count - index))) + index
            
            // If our current elements index is not the same as the randomly generated
            if index != randomIndex {
                        list.swapAt(index, randomIndex)
                
                }
            
            }
            
            return list

        }

    fileprivate func divideIntoGroups(_ studentNames: [String], _ numberOfGroups:Int) -> [[String]] {
    
    // 1. Create emptygroups up to numberOfGroups
    var groups = [[String]]()
    var i = 0

    while i < numberOfGroups {
    groups.append([String]())
    i += 1
    
        }
        
    
    
    // 2. Divide our passed in string array
    var groupNumber = 0
    
    
    // step through
        for studentName in studentNames {
            // Add student name to element of groups based on groupNumber
            groups[groupNumber].append(studentName)
        
            // Change group number for the next student name
            if groupNumber < numberOfGroups {
                groupNumber += 1
            } else {
                groupNumber = 0
            }
        }
        
        return groups
        
    }
        

        fileprivate func createOutputForGroup(_ groups: [String], withGroupNumber groupNumber: Int) -> String {
            
            var output = "Group \(groupNumber):\n"
            
            for student in groups {
                output += student + "\n"
            }
            return output + "\n"
        }
    }
