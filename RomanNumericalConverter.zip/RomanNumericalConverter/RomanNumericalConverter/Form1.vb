﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim intNumber As Integer

        'Convert
        If Integer.TryParse(txtNumber.Text, intNumber) Then

            'Translate the number to a Roman Numerical
            Select Case intNumber
                Case 1
                    lblRoman.Text = "I"
                Case 2
                    lblRoman.Text = "II"
                Case 3
                    lblRoman.Text = "III"
                Case 4
                    lblRoman.Text = "IV"
                Case 5
                    lblRoman.Text = "V"
                Case 6
                    lblRoman.Text = "VI"
                Case 7
                    lblRoman.Text = "VII"
                Case 8
                    lblRoman.Text = "VIII"
                Case 9
                    lblRoman.Text = "IX"
                Case 10
                    lblRoman.Text = "X"
                Case Else
                    'Display an error message
                    MessageBox.Show("Input is out of range.")
            End Select

        Else
            'Display an error message
            MessageBox.Show("Please enter a valied integer between 1-10.")
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
