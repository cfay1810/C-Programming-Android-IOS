/**
 * 
 */
package flooringCalculator;
/**
 * @author chelsey
 *
 */
public class FlooringCalculator {

	/**
	 * @param args
	 * 
	 * 
	 */
	public static void main(String[] args, int setLength, int setWidth) {
		// TODO Auto-generated method stub
		
		//Declare the variables
		double SquareFeet = (setLength * setWidth);
		double FloorCost = (8 * SquareFeet);
		
		
		//Create an instance for user input
		RoomFlooring roomflooring = new RoomFlooring();
		roomflooring.setRoomDimension();
		roomflooring.setFloorCost();
		
		//Get user input
		System.out.println("Enter the length of the room : ");
		System.out.println("Enter the width of the room : ");
		System.out.println("The squaredfeet of this room is : " + SquareFeet + "This room would cost : " + FloorCost);


		
	}

	}
		

