/**
 * 
 */
package flooringCalculator;

/**
 * @author Chelsey Fay
 *
 */
public class RoomDimension {
	
	private double setLength;
	private double setWidth;
	private String setSquareFeet;
	
	/**
	 * The setLength, setWidth, and setSquareFeet method accepts an argument
	 * that is stored in the length, width, and SquaredFeet field. 
	 * @return 
	 */
	
	public double setLength(){
		return setLength;
	}
	public void setLength(double Length){
		this.setLength = Length;
	}
	
	public double setWidth(){
		return setWidth;
	}
	public void setWidth(double width){
		this.setWidth = width;
	}
	public String setSquareFeet(){
		return setSquareFeet;
	}
	public void setSquareFeet(String SquareFeet){
		this.setSquareFeet = SquareFeet;
	}
}
