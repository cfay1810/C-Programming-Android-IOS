/**
 * 
 */
package flooringCalculator;

/**
 * @author Chelsey Fay
 *
 */
public class RoomFlooring {
		
		private Object setRoomDimension;
		private String setFloorCost;
		
		/**
		 * The setLength, setWidth, and setSquareFeet method accepts an argument
		 * that is stored in the length, width, and SquaredFeet field. 
		 * @return 
		 */
		
		public Object setRoomDimension(){
			return setRoomDimension;
		}
		public void setLength(Object RoomDimension){
			this.setRoomDimension = RoomDimension;
		}
		
		public String setFloorCost(){
			return setFloorCost;
		}
		public void setWidth(String FloorCost){
			this.setFloorCost = FloorCost;
		}
	
	}